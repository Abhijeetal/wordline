import { LightningElement,api } from 'lwc';

export default class EmailTemplate_messageIconButton extends LightningElement {
    @api
    firstPara=""
    @api
    buttonUrl=""
    @api
    secondPara=""
    @api
    imageUrl1=""
}