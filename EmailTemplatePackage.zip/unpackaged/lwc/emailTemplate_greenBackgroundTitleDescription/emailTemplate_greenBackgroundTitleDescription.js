import { LightningElement,api } from 'lwc';

export default class EmailTemplate_greenBackgroundTitleDescription extends LightningElement {
    @api title=""

    @api description=""
}