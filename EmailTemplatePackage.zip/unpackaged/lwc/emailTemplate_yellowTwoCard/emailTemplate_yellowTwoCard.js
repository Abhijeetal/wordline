import { LightningElement,api } from 'lwc';

export default class EmailTemplate_yellowTwoCard extends LightningElement {
    @api firstImageLink;
    @api secondImageLink;
    @api nameFirst;
    @api nameSecond;
    @api descriptionOne;
    @api endTitle="";
    @api nameThird;
    @api nameFourth
    @api nameFifth="";
    @api titleThree;
    @api linkOne
    @api linkTwo
}