import { LightningElement,api } from 'lwc';

export default class EmailTemplate_dateParagraph extends LightningElement {
    @api
    firstPara=""
    @api
    secondPara=""
}