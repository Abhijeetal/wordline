import { LightningElement,api } from 'lwc';

export default class EmailTemplate_ParagraphCard extends LightningElement {
    @api headline
    @api titleOne
    @api desc 
    @api linkOne
    @api emailOne
    @api titleTwo
    @api linkTwo
    @api linkText
    @api titleThree
}