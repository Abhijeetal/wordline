import { LightningElement,api } from 'lwc';

export default class EmailTemplate_titleParagraph extends LightningElement {
    @api 
    descriptionFirst=""
    @api 
    descriptionSecond=""
    @api 
    descriptionThird=""
    @api 
    descriptionFourth=""
    @api 
    descriptionFifth=""
    @api 
    descriptionSixth=""
    @api 
    descriptionSeventh=""
    @api 
    descriptionEighth=""
    @api
    email=""
}