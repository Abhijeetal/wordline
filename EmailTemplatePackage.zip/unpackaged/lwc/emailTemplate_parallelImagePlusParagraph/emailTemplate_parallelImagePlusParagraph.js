import { LightningElement,api } from 'lwc';

export default class EmailTemplate_parallelImagePlusParagraph extends LightningElement {
    @api
    imageUrl=""
    @api
    firstPara=""
    @api
    secondPara=""
    @api
    thirdPara=""
    @api
    fourthPara=""
    @api
    buttonUrl=""
}