import { LightningElement,api } from 'lwc';

export default class EmailTemplate_trenderAnalysis2 extends LightningElement {
    @api title1=""
    @api subTitle1=""
    @api description1=""
    @api button1=""
    @api hrefButtonName1=""
    @api image1URL=""
    @api title2=""
    @api subTitle2=""
    @api description2=""
    @api button2=""
    @api hrefButtonName2=""
    @api image2URL=""
    
}