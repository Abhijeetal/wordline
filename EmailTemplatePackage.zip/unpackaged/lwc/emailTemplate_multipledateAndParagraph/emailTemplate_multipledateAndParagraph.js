import { LightningElement,api } from 'lwc';

export default class EmailTemplate_multipledateAndParagraph extends LightningElement {
    @api
    imageUrl1=""
    @api
    imageUrl2=""
    @api
    imageUrl3=""
    @api
    firstPara=""
    @api
    secondPara
    @api
    thirdPara
    @api
    fourthPara
    @api
    fifthPara
    @api
    sixthPara
}