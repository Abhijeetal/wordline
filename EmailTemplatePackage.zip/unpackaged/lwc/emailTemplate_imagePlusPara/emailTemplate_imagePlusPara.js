import { LightningElement,api } from 'lwc';

export default class EmailTemplate_imagePlusPara extends LightningElement {
    @api imageUrl=""

    @api description=""
}