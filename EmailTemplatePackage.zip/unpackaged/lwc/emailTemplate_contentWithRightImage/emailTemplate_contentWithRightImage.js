import { LightningElement,api } from 'lwc';

export default class EmailTemplate_contentWithRightImage extends LightningElement {
    @api title='';
    @api header = '';
    @api contentBody = '';
    @api imageURL = '';
    @api buttonLink = '';
    @api buttonLabel = '';
}