import { LightningElement,api } from 'lwc';

export default class EmailTemplate_image600by250 extends LightningElement {
    @api imageUrl600=""
}