import { LightningElement,api } from 'lwc';

export default class EmailTemplate_imageParaEmail extends LightningElement {
    @api
    firstTitle=""
    @api
    secondTitle=""
    @api
    thirdTitle=""
    @api
    firstPara=""
    @api
    secondPara=""
    @api
    thirdPara=""
    @api
    button=""
    @api
    buttonLink=""
    @api
    imageUrl=""
    @api 
    email=""
}