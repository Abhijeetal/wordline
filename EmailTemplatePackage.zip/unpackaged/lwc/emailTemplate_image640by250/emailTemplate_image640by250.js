import { LightningElement,api } from 'lwc';

export default class EmailTemplate_image640by250 extends LightningElement {
    @api imageUrl640=""
}