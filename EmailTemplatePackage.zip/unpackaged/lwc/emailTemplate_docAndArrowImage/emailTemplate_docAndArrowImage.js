import { LightningElement,api } from 'lwc';

export default class EmailTemplate_docAndArrowImage extends LightningElement {
    @api
    imageUrl1=""
    @api
    imageUrl2=""

    @api
    firstPara=""
    @api
    secondPara=""
    @api
    thirdPara=""
    @api
    buttonUrl=""
}