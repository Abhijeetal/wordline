import { LightningElement,api } from 'lwc';

export default class EmailTemplate_twoCardsWithButton extends LightningElement {
    @api titleOne;
    @api linkOne;
    @api buttonName='';
    @api titleTwo;
    @api buttonTwo='';
}