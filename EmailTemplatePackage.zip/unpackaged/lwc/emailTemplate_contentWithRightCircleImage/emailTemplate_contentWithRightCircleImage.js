import { LightningElement,api } from 'lwc';

export default class EmailTemplate_contentWithRightCircleImage extends LightningElement {
    @api headline='';
    @api contentBody = '';
    @api imageURL = '';
    @api buttonLink = '';
    @api buttonLabel = '';
}