import { LightningElement,api } from 'lwc';

export default class EmailTemplate_ThreePara3Button3Image3Paragraph extends LightningElement {
    @api image1=""

    @api image2=""

    @api image3=""

    @api buttonName1=""

    @api buttonName2=""

    @api buttonName3=""

    @api hrefButtonName1=""

    @api hrefButtonName2=""

    @api hrefButtonName3=""

    @api para1=""
    
    @api para2=""
    
    @api para3=""
    
    @api para4=""
    
    @api para5=""
    
    @api para6=""
}