import { LightningElement,api } from 'lwc';

export default class EmailTemplate_parallelParagraphDup extends LightningElement {
    @api
firstPara=""
@api
secondPara=""
@api
thirdPara=""
@api
fourthPara=""
@api
fifthPara=""
@api
sixthPara=""
@api
seventhPara=""
@api
eighthPara=""
@api
ninethPara=""
@api
tenthPara=""
@api
eleventhPara=""
@api
twelthPara=""
@api
buttonLink1=""
@api
thirteenthPara=""
@api
buttonLink2=""
}