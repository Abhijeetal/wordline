import { LightningElement,api } from 'lwc';

export default class EmailTemplate_multipleTitleBlock extends LightningElement {
    @api Title1=""
    @api Title2=""
    @api Button=""
}