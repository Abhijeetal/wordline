import { LightningElement,api } from 'lwc';

export default class EmailTemplate_greenBg3Para3Button extends LightningElement {
    @api title=""

    @api para1=""

    @api para2=""

    @api para3=""

    @api buttonName1=""

    @api buttonName2=""
    
    @api buttonName3=""

    @api hrefButtonName1=""

    @api hrefButtonName2=""
    
    @api hrefButtonName3=""
}