import { LightningElement,api } from 'lwc';

export default class EmailTemplate_twoCardsWithoutButton extends LightningElement {
    @api titleOne;
    @api titleTwo;
}