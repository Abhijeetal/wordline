import { LightningElement,api } from 'lwc';

export default class EmailTemplate_whitebackgroundPlusButton extends LightningElement {
    @ api description=""

    @api button=""

    @api hrefButtonName1=""
}