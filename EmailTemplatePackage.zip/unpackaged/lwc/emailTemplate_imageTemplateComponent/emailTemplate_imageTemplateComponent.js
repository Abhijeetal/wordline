import { LightningElement,api } from 'lwc';

export default class EmailTemplate_imageTemplateComponent extends LightningElement {
    @api
    imageUrl=""
    @api
    imageUrl2=""
    @api
    imageUrl3=""
    @api
    imageUrl4=""
    @api
    imageUrl5=""
    @api
    imageUrl6=""
    @api
    imageUrl7=""
    @api
    imageUrl8=""
}