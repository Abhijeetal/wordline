import { LightningElement,api } from 'lwc';

export default class EmailTemplate_imageWithParaAndButton extends LightningElement {
    @api
    title1=""
    @api
    subtitle=""
    @api
    title3=""
    @api
    imageUrl=""
    @api
    description=""
    @api
    buttonName=""
    @api
    buttonUrl=""    
    @api
    description2=""
    @api
    email=""
}