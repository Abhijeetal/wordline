import { LightningElement,api } from 'lwc';

export default class EmailTemplate_imageParaAndButton extends LightningElement {
    @api 
    imageUrl1=""
    @api
    firstTitle=""
    @api
    secondTitle=""
    @api
    thirdTitle=""
    @api
    fourthTitle=""
    @api
    fifthTitle=""
    @api
    sixthTitle=""
    @api
    firstPara=""
    @api
    secondPara=""
    @api
    thirdPara=""
    @api
    fourthPara=""
    @api
    fifthPara=""
    @api
    sixthPara=""
    @api
    imageUrl
    @api
    button=""
}