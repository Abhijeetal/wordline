import { LightningElement,api } from 'lwc';

export default class EmailTemplate_ParallelHeadingComponent extends LightningElement {
    @api
    firstPara=""
    @api
    secondPara=""
    @api
    thirdPara=""
}