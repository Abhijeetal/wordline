import { LightningElement,api  } from 'lwc';

export default class EmailTemplate_multipleImageWithButton extends LightningElement {
    @api img1='';
    @api buttonLabel1='';
    @api buttonLink1='';
    @api img2='';
    @api buttonLabel2='';
    @api buttonLink2='';
    @api img3='';
    @api buttonLabel3='';
    @api buttonLink3='';
}