import { LightningElement, api } from 'lwc';
 import ProjectResourcesRK from '@salesforce/resourceUrl/ProjectResourcesRK'

export default class EmailTemplate_digitalTransformationSection extends LightningElement {
    @api firstProperty;
    @api title
    @api heading;
    @api headline;
    @api label;
    @api firstImage;
    @api secondHeadline;
    @api secondTitle
    @api secondImage
}