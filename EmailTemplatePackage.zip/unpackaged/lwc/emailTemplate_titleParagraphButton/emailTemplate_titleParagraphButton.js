import { LightningElement,api } from 'lwc';

export default class EmailTemplate_titleParagraphButton extends LightningElement {
    @api titleToThis=""

    @api description=""

    @api button=""

    @api hrefButtonName1=""
    
}