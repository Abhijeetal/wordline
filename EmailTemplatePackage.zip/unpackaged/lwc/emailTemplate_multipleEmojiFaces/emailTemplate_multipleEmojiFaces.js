import { LightningElement,api } from 'lwc';

export default class EmailTemplate_multipleEmojiFaces extends LightningElement {
    @api
    imageUrl1=""
    @api
    imageUrl2=""
    @api
    imageUrl3=""
    @api
    imageUrl4=""
    @api
    firstPara=""
    @api
    buttonUrl=""
    @api
    secondPara=""
    @api
    thirdPara=""
}